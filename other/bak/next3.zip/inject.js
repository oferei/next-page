window.addEventListener("keydown", function(event) {
  // Bind to both command (for Mac) and control (for Win/Linux)
  var modifier = event.ctrlKey || event.metaKey;
  if (modifier && event.shiftKey && event.keyCode == 39) {
    // Send message to background page
    chrome.extension.sendRequest({open_next_kbs: true}, function(response) {
      // Do stuff on successful response
    });
  }
  if (modifier && event.shiftKey && event.keyCode == 37) {
    // Send message to background page
    chrome.extension.sendRequest({open_prev_kbs: true}, function(response) {
      // Do stuff on successful response
    });
  }
}, false);
