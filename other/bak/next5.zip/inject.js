// Get configuration
var modifier1 = undefined;
chrome.extension.sendRequest({method: 'getLocalStorage', key: 'favorite_modifier1'}, function(response) {
  modifier1 = response.data;
  //console.log('Next Page modifier1: ' + modifier1);
});

var modifier2 = undefined;
chrome.extension.sendRequest({method: 'getLocalStorage', key: 'favorite_modifier2'}, function(response) {
  modifier2 = response.data;
  //console.log('Next Page modifier2: ' + modifier2);
});


function get_modifier(modifier, event) {
  if (modifier == 'none') {
    //console.log('modifier none is true');
    return true;
  } else if (modifier == 'ctrl') {
    //console.log('modifier ctrl is ' + event.ctrlKey || event.metaKey);
    return event.ctrlKey || event.metaKey;
  } else if (modifier == 'alt') {
    //console.log('modifier alt is ' + event.altKey);
    return event.altKey;
  } else if (modifier == 'shift') {
    //console.log('modifier shift is ' + event.shiftKey);
    return event.shiftKey;
  } else {
    console.log('unknown modifier: ' + modifier);
    // unreachable
    return false;
  }
}

window.addEventListener("keydown", function(event) {

  //var favorite = localStorage['favorite_modifier1'];
  //alert('favorite: ' + favorite);
  var modifier = event.ctrlKey || event.metaKey;

  //console.log('modifier1: ' + modifier1 + ' modifier2: ' + modifier2);

  if (get_modifier(modifier1 || 'ctrl', event) && get_modifier(modifier2 || 'shift', event)) {
    //console.log('modifiers are true. keycode: ' + event.keyCode);
    if (event.keyCode == 39) { // 39 = right
      // Send message to background page
      chrome.extension.sendRequest({method: 'open_next_kbs'}, function(response) {
        // Do stuff on successful response
      });
    }
    if (event.keyCode == 37) { // 37 = left
      // Send message to background page
      chrome.extension.sendRequest({method: 'open_prev_kbs'}, function(response) {
        // Do stuff on successful response
      });
    }
  }
}, false);
