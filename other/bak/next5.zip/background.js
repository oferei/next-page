chrome.extension.onRequest.addListener(
  function(request, sender, sendResponse) {
    if (request.method == "getLocalStorage") {
      // Get the currently selected tab
      sendResponse({data: localStorage[request.key]});
    }
    if (request.method == "open_next_kbs") {
      // Get the currently selected tab
      chrome.tabs.getSelected(null, function(tab) {
        chrome.tabs.executeScript(tab.id, {file: "next.js"});
      });
    }
    if (request.method == "open_prev_kbs") {
      // Get the currently selected tab
      chrome.tabs.getSelected(null, function(tab) {
        chrome.tabs.executeScript(tab.id, {file: "prev.js"});
      });
    }
  }
);
