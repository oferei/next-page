//alert('js');
var prev_re = new RegExp("\\bprev\\b", 'i');
var prev2_re = new RegExp("\\bprevious\\b", 'i');

var els = document.body.getElementsByTagName('a');
var elsLen = els.length;
for (i = 0; i < elsLen; i++) {
  if (els[i].rel == 'prev' || prev_re.test(els[i].innerHTML) || prev2_re.test(els[i].innerHTML)) {
    document.location.href = els[i].href;
    break;
  }
}
