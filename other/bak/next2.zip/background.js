chrome.extension.onRequest.addListener(
  function(request, sender, sendResponse) {
    if (request.open_next_kbs) {
      // Get the currently selected tab
      chrome.tabs.getSelected(null, function(tab) {
        //alert("key pressed.");
        //chrome.tabs.update(tab.id, {url: 'http://www.abc.com'});
        //chrome.tabs.executeScript(null, {code:"document.body.style.background='red'"});
        //chrome.tabs.executeScript(null, {code:"document.body.innerHTML='abc'"});
        chrome.tabs.executeScript(tab.id, {file: "next.js"});
      });
    }
    if (request.open_prev_kbs) {
      // Get the currently selected tab
      chrome.tabs.getSelected(null, function(tab) {
        //alert("key pressed.");
        chrome.tabs.executeScript(tab.id, {file: "prev.js"});
      });
    }
  }
);
