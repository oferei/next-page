//var strip_re = new RegExp("<(?:.|\n)*?>", 'gm');
var strip_re = new RegExp("<[^>]*>", 'gm');
var next_re = new RegExp("^\\s*next\\s*$", 'i');

var els = document.body.getElementsByTagName('a');
var elsLen = els.length;
var found = false;
for (i = 0; i < elsLen; i++) {
  if (els[i].rel == 'next') {
    found = true;
  } else {
    var txt = els[i].innerHTML.replace(strip_re, '');
    //alert('before: ' + els[i].innerHTML + ', after: ' + txt);
    if (next_re.test(txt)) {
      found = true;
    }
  }

  if (found) {
    alert('found! rel: ' + els[i].rel + ', innerHTML: ' + els[i].innerHTML);
    document.location.href = els[i].href;
    break;
  }
}
